package routines;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */



import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.TalendDate;
import routines.Relational;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: routUsageLog_machine2 Purpose: Get usage log from machine2
 * and fill usage multidim model<br>
 * Description: Get usage log from machine2 and fill usage multidim
 * model <br>
 * 
 * @author user@talend.com
 * @version 7.2.1.20190620_1446
 * @status DEV
 */
public class routUsageLog_machine2 implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "routUsageLog_machine2";
	private final String projectName = "NFE211_1";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					routUsageLog_machine2.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(routUsageLog_machine2.this,
									new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBConnection_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBConnection_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBConnection_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBConnection_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBConnection_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBConnection_4_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBConnection_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBConnection_5_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBConnection_6_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBConnection_6_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBConnection_3_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBConnection_4_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBConnection_5_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBConnection_6_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBConnection_1 begin ] start
				 */

				ok_Hash.put("tDBConnection_1", false);
				start_Hash.put("tDBConnection_1", System.currentTimeMillis());

				currentComponent = "tDBConnection_1";

				int tos_count_tDBConnection_1 = 0;

				String properties_tDBConnection_1 = "noDatetimeStringSync=true";
				if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
					properties_tDBConnection_1 += "rewriteBatchedStatements=true";
				} else if (properties_tDBConnection_1 != null
						&& !properties_tDBConnection_1.contains("rewriteBatchedStatements")) {
					properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
				}

				String url_tDBConnection_1 = "jdbc:mysql://" + "10.164.1.112" + ":" + "3306" + "/" + "machine2" + "?"
						+ properties_tDBConnection_1;
				String dbUser_tDBConnection_1 = "dwh";

				final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("ENC:[qQepfTU4WCZdahh2wEY1oA==]");
				String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;

				java.sql.Connection conn_tDBConnection_1 = null;

				String driverClass_tDBConnection_1 = "com.mysql.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);

				conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1, dbUser_tDBConnection_1,
						dbPwd_tDBConnection_1);

				globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
				if (null != conn_tDBConnection_1) {

					conn_tDBConnection_1.setAutoCommit(false);
				}

				globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);

				globalMap.put("db_tDBConnection_1", "machine2");

				/**
				 * [tDBConnection_1 begin ] stop
				 */

				/**
				 * [tDBConnection_1 main ] start
				 */

				currentComponent = "tDBConnection_1";

				tos_count_tDBConnection_1++;

				/**
				 * [tDBConnection_1 main ] stop
				 */

				/**
				 * [tDBConnection_1 process_data_begin ] start
				 */

				currentComponent = "tDBConnection_1";

				/**
				 * [tDBConnection_1 process_data_begin ] stop
				 */

				/**
				 * [tDBConnection_1 process_data_end ] start
				 */

				currentComponent = "tDBConnection_1";

				/**
				 * [tDBConnection_1 process_data_end ] stop
				 */

				/**
				 * [tDBConnection_1 end ] start
				 */

				currentComponent = "tDBConnection_1";

				ok_Hash.put("tDBConnection_1", true);
				end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				/**
				 * [tDBConnection_1 end ] stop
				 */
			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			tDBConnection_2Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDBConnection_1 finally ] start
				 */

				currentComponent = "tDBConnection_1";

				/**
				 * [tDBConnection_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}

	public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBConnection_2 begin ] start
				 */

				ok_Hash.put("tDBConnection_2", false);
				start_Hash.put("tDBConnection_2", System.currentTimeMillis());

				currentComponent = "tDBConnection_2";

				int tos_count_tDBConnection_2 = 0;

				String properties_tDBConnection_2 = "noDatetimeStringSync=true";
				if (properties_tDBConnection_2 == null || properties_tDBConnection_2.trim().length() == 0) {
					properties_tDBConnection_2 += "rewriteBatchedStatements=true";
				} else if (properties_tDBConnection_2 != null
						&& !properties_tDBConnection_2.contains("rewriteBatchedStatements")) {
					properties_tDBConnection_2 += "&rewriteBatchedStatements=true";
				}

				String url_tDBConnection_2 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "dwhouse" + "?"
						+ properties_tDBConnection_2;
				String dbUser_tDBConnection_2 = "dwh";

				final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("ENC:[qQepfTU4WCZdahh2wEY1oA==]");
				String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;

				java.sql.Connection conn_tDBConnection_2 = null;

				String driverClass_tDBConnection_2 = "com.mysql.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);

				conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2, dbUser_tDBConnection_2,
						dbPwd_tDBConnection_2);

				globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
				if (null != conn_tDBConnection_2) {

					conn_tDBConnection_2.setAutoCommit(false);
				}

				globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);

				globalMap.put("db_tDBConnection_2", "dwhouse");

				/**
				 * [tDBConnection_2 begin ] stop
				 */

				/**
				 * [tDBConnection_2 main ] start
				 */

				currentComponent = "tDBConnection_2";

				tos_count_tDBConnection_2++;

				/**
				 * [tDBConnection_2 main ] stop
				 */

				/**
				 * [tDBConnection_2 process_data_begin ] start
				 */

				currentComponent = "tDBConnection_2";

				/**
				 * [tDBConnection_2 process_data_begin ] stop
				 */

				/**
				 * [tDBConnection_2 process_data_end ] start
				 */

				currentComponent = "tDBConnection_2";

				/**
				 * [tDBConnection_2 process_data_end ] stop
				 */

				/**
				 * [tDBConnection_2 end ] start
				 */

				currentComponent = "tDBConnection_2";

				ok_Hash.put("tDBConnection_2", true);
				end_Hash.put("tDBConnection_2", System.currentTimeMillis());

				/**
				 * [tDBConnection_2 end ] stop
				 */
			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_2:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			tDBConnection_3Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDBConnection_2 finally ] start
				 */

				currentComponent = "tDBConnection_2";

				/**
				 * [tDBConnection_2 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}

	public void tDBConnection_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBConnection_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBConnection_3 begin ] start
				 */

				ok_Hash.put("tDBConnection_3", false);
				start_Hash.put("tDBConnection_3", System.currentTimeMillis());

				currentComponent = "tDBConnection_3";

				int tos_count_tDBConnection_3 = 0;

				String properties_tDBConnection_3 = "noDatetimeStringSync=true";
				if (properties_tDBConnection_3 == null || properties_tDBConnection_3.trim().length() == 0) {
					properties_tDBConnection_3 += "rewriteBatchedStatements=true";
				} else if (properties_tDBConnection_3 != null
						&& !properties_tDBConnection_3.contains("rewriteBatchedStatements")) {
					properties_tDBConnection_3 += "&rewriteBatchedStatements=true";
				}

				String url_tDBConnection_3 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "components_inventory"
						+ "?" + properties_tDBConnection_3;
				String dbUser_tDBConnection_3 = "dwh";

				final String decryptedPassword_tDBConnection_3 = routines.system.PasswordEncryptUtil
						.decryptPassword("ENC:[qQepfTU4WCZdahh2wEY1oA==]");
				String dbPwd_tDBConnection_3 = decryptedPassword_tDBConnection_3;

				java.sql.Connection conn_tDBConnection_3 = null;

				String driverClass_tDBConnection_3 = "com.mysql.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBConnection_3 = java.lang.Class.forName(driverClass_tDBConnection_3);

				conn_tDBConnection_3 = java.sql.DriverManager.getConnection(url_tDBConnection_3, dbUser_tDBConnection_3,
						dbPwd_tDBConnection_3);

				globalMap.put("conn_tDBConnection_3", conn_tDBConnection_3);
				if (null != conn_tDBConnection_3) {

					conn_tDBConnection_3.setAutoCommit(false);
				}

				globalMap.put("conn_tDBConnection_3", conn_tDBConnection_3);

				globalMap.put("db_tDBConnection_3", "components_inventory");

				/**
				 * [tDBConnection_3 begin ] stop
				 */

				/**
				 * [tDBConnection_3 main ] start
				 */

				currentComponent = "tDBConnection_3";

				tos_count_tDBConnection_3++;

				/**
				 * [tDBConnection_3 main ] stop
				 */

				/**
				 * [tDBConnection_3 process_data_begin ] start
				 */

				currentComponent = "tDBConnection_3";

				/**
				 * [tDBConnection_3 process_data_begin ] stop
				 */

				/**
				 * [tDBConnection_3 process_data_end ] start
				 */

				currentComponent = "tDBConnection_3";

				/**
				 * [tDBConnection_3 process_data_end ] stop
				 */

				/**
				 * [tDBConnection_3 end ] start
				 */

				currentComponent = "tDBConnection_3";

				ok_Hash.put("tDBConnection_3", true);
				end_Hash.put("tDBConnection_3", System.currentTimeMillis());

				/**
				 * [tDBConnection_3 end ] stop
				 */
			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_3:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			tDBConnection_4Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDBConnection_3 finally ] start
				 */

				currentComponent = "tDBConnection_3";

				/**
				 * [tDBConnection_3 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBConnection_3_SUBPROCESS_STATE", 1);
	}

	public void tDBConnection_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBConnection_4_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBConnection_4 begin ] start
				 */

				ok_Hash.put("tDBConnection_4", false);
				start_Hash.put("tDBConnection_4", System.currentTimeMillis());

				currentComponent = "tDBConnection_4";

				int tos_count_tDBConnection_4 = 0;

				String properties_tDBConnection_4 = "noDatetimeStringSync=true";
				if (properties_tDBConnection_4 == null || properties_tDBConnection_4.trim().length() == 0) {
					properties_tDBConnection_4 += "rewriteBatchedStatements=true";
				} else if (properties_tDBConnection_4 != null
						&& !properties_tDBConnection_4.contains("rewriteBatchedStatements")) {
					properties_tDBConnection_4 += "&rewriteBatchedStatements=true";
				}

				String url_tDBConnection_4 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "factory" + "?"
						+ properties_tDBConnection_4;
				String dbUser_tDBConnection_4 = "dwh";

				final String decryptedPassword_tDBConnection_4 = routines.system.PasswordEncryptUtil
						.decryptPassword("ENC:[qQepfTU4WCZdahh2wEY1oA==]");
				String dbPwd_tDBConnection_4 = decryptedPassword_tDBConnection_4;

				java.sql.Connection conn_tDBConnection_4 = null;

				String driverClass_tDBConnection_4 = "com.mysql.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBConnection_4 = java.lang.Class.forName(driverClass_tDBConnection_4);

				conn_tDBConnection_4 = java.sql.DriverManager.getConnection(url_tDBConnection_4, dbUser_tDBConnection_4,
						dbPwd_tDBConnection_4);

				globalMap.put("conn_tDBConnection_4", conn_tDBConnection_4);
				if (null != conn_tDBConnection_4) {

					conn_tDBConnection_4.setAutoCommit(false);
				}

				globalMap.put("conn_tDBConnection_4", conn_tDBConnection_4);

				globalMap.put("db_tDBConnection_4", "factory");

				/**
				 * [tDBConnection_4 begin ] stop
				 */

				/**
				 * [tDBConnection_4 main ] start
				 */

				currentComponent = "tDBConnection_4";

				tos_count_tDBConnection_4++;

				/**
				 * [tDBConnection_4 main ] stop
				 */

				/**
				 * [tDBConnection_4 process_data_begin ] start
				 */

				currentComponent = "tDBConnection_4";

				/**
				 * [tDBConnection_4 process_data_begin ] stop
				 */

				/**
				 * [tDBConnection_4 process_data_end ] start
				 */

				currentComponent = "tDBConnection_4";

				/**
				 * [tDBConnection_4 process_data_end ] stop
				 */

				/**
				 * [tDBConnection_4 end ] start
				 */

				currentComponent = "tDBConnection_4";

				ok_Hash.put("tDBConnection_4", true);
				end_Hash.put("tDBConnection_4", System.currentTimeMillis());

				/**
				 * [tDBConnection_4 end ] stop
				 */
			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_4:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			tDBConnection_5Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDBConnection_4 finally ] start
				 */

				currentComponent = "tDBConnection_4";

				/**
				 * [tDBConnection_4 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBConnection_4_SUBPROCESS_STATE", 1);
	}

	public void tDBConnection_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBConnection_5_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBConnection_5 begin ] start
				 */

				ok_Hash.put("tDBConnection_5", false);
				start_Hash.put("tDBConnection_5", System.currentTimeMillis());

				currentComponent = "tDBConnection_5";

				int tos_count_tDBConnection_5 = 0;

				String properties_tDBConnection_5 = "noDatetimeStringSync=true";
				if (properties_tDBConnection_5 == null || properties_tDBConnection_5.trim().length() == 0) {
					properties_tDBConnection_5 += "rewriteBatchedStatements=true";
				} else if (properties_tDBConnection_5 != null
						&& !properties_tDBConnection_5.contains("rewriteBatchedStatements")) {
					properties_tDBConnection_5 += "&rewriteBatchedStatements=true";
				}

				String url_tDBConnection_5 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "machine_inventory"
						+ "?" + properties_tDBConnection_5;
				String dbUser_tDBConnection_5 = "dwh";

				final String decryptedPassword_tDBConnection_5 = routines.system.PasswordEncryptUtil
						.decryptPassword("ENC:[qQepfTU4WCZdahh2wEY1oA==]");
				String dbPwd_tDBConnection_5 = decryptedPassword_tDBConnection_5;

				java.sql.Connection conn_tDBConnection_5 = null;

				String driverClass_tDBConnection_5 = "com.mysql.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBConnection_5 = java.lang.Class.forName(driverClass_tDBConnection_5);

				conn_tDBConnection_5 = java.sql.DriverManager.getConnection(url_tDBConnection_5, dbUser_tDBConnection_5,
						dbPwd_tDBConnection_5);

				globalMap.put("conn_tDBConnection_5", conn_tDBConnection_5);
				if (null != conn_tDBConnection_5) {

					conn_tDBConnection_5.setAutoCommit(false);
				}

				globalMap.put("conn_tDBConnection_5", conn_tDBConnection_5);

				globalMap.put("db_tDBConnection_5", "machine_inventory");

				/**
				 * [tDBConnection_5 begin ] stop
				 */

				/**
				 * [tDBConnection_5 main ] start
				 */

				currentComponent = "tDBConnection_5";

				tos_count_tDBConnection_5++;

				/**
				 * [tDBConnection_5 main ] stop
				 */

				/**
				 * [tDBConnection_5 process_data_begin ] start
				 */

				currentComponent = "tDBConnection_5";

				/**
				 * [tDBConnection_5 process_data_begin ] stop
				 */

				/**
				 * [tDBConnection_5 process_data_end ] start
				 */

				currentComponent = "tDBConnection_5";

				/**
				 * [tDBConnection_5 process_data_end ] stop
				 */

				/**
				 * [tDBConnection_5 end ] start
				 */

				currentComponent = "tDBConnection_5";

				ok_Hash.put("tDBConnection_5", true);
				end_Hash.put("tDBConnection_5", System.currentTimeMillis());

				/**
				 * [tDBConnection_5 end ] stop
				 */
			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_5:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			tDBConnection_6Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDBConnection_5 finally ] start
				 */

				currentComponent = "tDBConnection_5";

				/**
				 * [tDBConnection_5 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBConnection_5_SUBPROCESS_STATE", 1);
	}

	public void tDBConnection_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBConnection_6_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBConnection_6 begin ] start
				 */

				ok_Hash.put("tDBConnection_6", false);
				start_Hash.put("tDBConnection_6", System.currentTimeMillis());

				currentComponent = "tDBConnection_6";

				int tos_count_tDBConnection_6 = 0;

				String properties_tDBConnection_6 = "noDatetimeStringSync=true";
				if (properties_tDBConnection_6 == null || properties_tDBConnection_6.trim().length() == 0) {
					properties_tDBConnection_6 += "rewriteBatchedStatements=true";
				} else if (properties_tDBConnection_6 != null
						&& !properties_tDBConnection_6.contains("rewriteBatchedStatements")) {
					properties_tDBConnection_6 += "&rewriteBatchedStatements=true";
				}

				String url_tDBConnection_6 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "supplies" + "?"
						+ properties_tDBConnection_6;
				String dbUser_tDBConnection_6 = "dwh";

				final String decryptedPassword_tDBConnection_6 = routines.system.PasswordEncryptUtil
						.decryptPassword("ENC:[qQepfTU4WCZdahh2wEY1oA==]");
				String dbPwd_tDBConnection_6 = decryptedPassword_tDBConnection_6;

				java.sql.Connection conn_tDBConnection_6 = null;

				String driverClass_tDBConnection_6 = "com.mysql.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBConnection_6 = java.lang.Class.forName(driverClass_tDBConnection_6);

				conn_tDBConnection_6 = java.sql.DriverManager.getConnection(url_tDBConnection_6, dbUser_tDBConnection_6,
						dbPwd_tDBConnection_6);

				globalMap.put("conn_tDBConnection_6", conn_tDBConnection_6);
				if (null != conn_tDBConnection_6) {

					conn_tDBConnection_6.setAutoCommit(false);
				}

				globalMap.put("conn_tDBConnection_6", conn_tDBConnection_6);

				globalMap.put("db_tDBConnection_6", "supplies");

				/**
				 * [tDBConnection_6 begin ] stop
				 */

				/**
				 * [tDBConnection_6 main ] start
				 */

				currentComponent = "tDBConnection_6";

				tos_count_tDBConnection_6++;

				/**
				 * [tDBConnection_6 main ] stop
				 */

				/**
				 * [tDBConnection_6 process_data_begin ] start
				 */

				currentComponent = "tDBConnection_6";

				/**
				 * [tDBConnection_6 process_data_begin ] stop
				 */

				/**
				 * [tDBConnection_6 process_data_end ] start
				 */

				currentComponent = "tDBConnection_6";

				/**
				 * [tDBConnection_6 process_data_end ] stop
				 */

				/**
				 * [tDBConnection_6 end ] start
				 */

				currentComponent = "tDBConnection_6";

				ok_Hash.put("tDBConnection_6", true);
				end_Hash.put("tDBConnection_6", System.currentTimeMillis());

				/**
				 * [tDBConnection_6 end ] stop
				 */
			} // end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_6:OnSubjobOk", "",
						Thread.currentThread().getId() + "", "", "", "", "", "");
			}

			tDBInput_1Process(globalMap);

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDBConnection_6 finally ] start
				 */

				currentComponent = "tDBConnection_6";

				/**
				 * [tDBConnection_6 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBConnection_6_SUBPROCESS_STATE", 1);
	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
		
		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
				calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
				int nb_line_tDBInput_1 = 0;
				
				/*variable declaration for dimension keys*/
				int key_machinelocation;
				/*variable declaration for kwh fact*/
							
				
				
				/*get connection JES start*/
				//machine2
				java.sql.Connection conn_machine2 = null;
				conn_machine2 = (java.sql.Connection) globalMap.get("conn_tDBConnection_1");
				//dwhouse 
				java.sql.Connection conn_dwhouse = null;
				conn_dwhouse = (java.sql.Connection) globalMap.get("conn_tDBConnection_2");
				//components_inventory
				java.sql.Connection conn_components_inventory = null;
				conn_components_inventory = (java.sql.Connection) globalMap.get("conn_tDBConnection_3");
				//factory
				java.sql.Connection conn_factory = null;
				conn_factory = (java.sql.Connection) globalMap.get("conn_tDBConnection_4");
				//machine_inventory
				java.sql.Connection conn_machine_inventory = null;
				conn_machine_inventory = (java.sql.Connection) globalMap.get("conn_tDBConnection_5");
				//supplies
				java.sql.Connection conn_supplies = null;
				conn_supplies = (java.sql.Connection) globalMap.get("conn_tDBConnection_6");
				/*get connection JES end*/

				/*create statement JES start*/
				java.sql.Statement stmt_machine2 = conn_machine2.createStatement();
				java.sql.Statement stmt_dwhouse = conn_dwhouse.createStatement();
				java.sql.Statement stmt_components_inventory = conn_components_inventory.createStatement();
				java.sql.Statement stmt_factory = conn_factory.createStatement();
				java.sql.Statement stmt_machine_inventory = conn_machine_inventory.createStatement();
				java.sql.Statement stmt_supplies = conn_supplies.createStatement();				
				/*create statement JES end*/

				/*define which machine is going to be process by using its serial number JES start*/
				String machine_serialnbr = "50002P";
				/*define which machine is going to be process JES end*/
				
				/*get machine information from machinelocation_dim and get key_machinelocation JES start*/
				String dbquery_getKeydim = "SELECT key_dim FROM machinelocation_dim where machine = '"+ machine_serialnbr+"'";
				java.sql.ResultSet rs_getKeydim = null;				
				rs_getKeydim = stmt_dwhouse.executeQuery(dbquery_getKeydim);				
				/*Need to check if result is null, test next()*/
				rs_getKeydim.next();
				key_machinelocation = rs_getKeydim.getInt("key_dim");				
				/*get machine information from machinelocation_dim and get key_machinelocation JES end*/
								

				String dbquery_getUsageLog = "SELECT \n  `usage_log`.`logid`, \n  `usage_log`.`compid`, \n  `usage_log`.`logdate`, \n  `usage_log`.`logtime`, \n  `usage_log`.`week`, " 
						+ "\n  `usage_log`.`actionsnbr`, \n  `usage_log`.`usageduration`\nFROM `usage_log`";
				
				globalMap.put("dbquery_getConsumptLog", dbquery_getUsageLog);
				java.sql.ResultSet rs_getUsagetLog = null;
				
				try {
					rs_getUsagetLog = stmt_machine2.executeQuery(dbquery_getUsageLog);					
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_getUsagetLog.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;
					
					int hour, day, week, month, year; 
					
					/*key dimension*/
					int key_time_dim, key_comp_dim;
					/*fact */
					int actionsNbr, usageDurationMinutes, compIDinMachine, compIDinInventary;
					
					float lifespan;
					
					/*to store part and serial number*/
					int partNumber;
					String serialNbr;
					
					while (rs_getUsagetLog.next()) {
						nb_line_tDBInput_1++;

						/**
						 * [tDBInput_1 begin ] stop
						 */

						hour = Integer.parseInt(rs_getUsagetLog.getString(4).substring(0, 2));
						day = Integer.parseInt(rs_getUsagetLog.getString(3).substring(8, 10));
						month = Integer.parseInt(rs_getUsagetLog.getString(3).substring(5, 7));
						year = Integer.parseInt(rs_getUsagetLog.getString(3).substring(0, 4));
						week = rs_getUsagetLog.getInt(5);
						actionsNbr = rs_getUsagetLog.getInt(6);
						compIDinMachine = rs_getUsagetLog.getInt(2);
						
						/*We need to get part and serial number for this compIDinMachine*/
						String dbquery_getPartSerNbr = "SELECT * FROM machine2.machine_components where compid='" + compIDinMachine +"'";
						java.sql.Statement stmt_machine2_1 = conn_machine2.createStatement();
						java.sql.ResultSet rs_getPartSerNbr = stmt_machine2_1.executeQuery(dbquery_getPartSerNbr);
						rs_getPartSerNbr.next();
						partNumber= rs_getPartSerNbr.getInt(2);
						serialNbr= rs_getPartSerNbr.getString(3);
						
						/*Get the component ID from the general components inventory*/
						String dbquery_getCompID = "SELECT id FROM components_inventory.components where partnbr='" + partNumber + "' and serialnbr='"+ serialNbr +"'" ;
						java.sql.ResultSet rs_getCompID = stmt_components_inventory.executeQuery(dbquery_getCompID);
						rs_getCompID.next();						
						compIDinInventary= rs_getCompID.getInt(1);
						
						/*Now we need to get the key_component from component_dim*/
						String dbquery_getKeyCompDIm = "SELECT key_dim FROM dwhouse.component_dim where compidinventory='" + compIDinInventary + "'";
						java.sql.Statement stmt_dwhouse1 = conn_dwhouse.createStatement();
						java.sql.ResultSet rs_getKeyCompDIm = stmt_dwhouse1.executeQuery(dbquery_getKeyCompDIm);
						rs_getKeyCompDIm.next();
						key_comp_dim= rs_getKeyCompDIm.getInt(1);
						
						/*get number of actions max lifespan from supplies.partnumbers only for family that applies*/
						String dbquery_getLifeSpan = "SELECT lifespan FROM supplies.partnumbers where lifespanunit='2' and partnbr='" + partNumber +"'";
						java.sql.ResultSet rs_getLifeSpan = stmt_supplies.executeQuery(dbquery_getLifeSpan);
						if(!rs_getLifeSpan.next())
						{
							continue;							
						}												
						
						lifespan = rs_getLifeSpan.getFloat(1);
						
						/*See if the log time/date already exist in table time_dim
						 * If it exists then get the key_dim
						 * If it does not exist then add it to table time _dim
						 * 
						 * Then with this we are filling time dimension
						 * 
						 * */
						String dbquery_getKeyTimeDim = "SELECT key_dim FROM dwhouse.time_dim where hour =" + hour + " and day=" + day + " and week=" +week+" and month="+ month +" and year="+ year;
						java.sql.ResultSet rs_getKeyTimeDim = null;
						rs_getKeyTimeDim = stmt_dwhouse.executeQuery(dbquery_getKeyTimeDim);
						
						if(!rs_getKeyTimeDim.next())
						{
							String insertTimeDim = "INSERT INTO `" + "time_dim"
									+ "` (`hour`,`day`,`week`,`month`,`year`) VALUES (?,?,?,?,?)"; 
							
							java.sql.PreparedStatement pstmt_insertTimeDim = conn_dwhouse.prepareStatement(insertTimeDim);
							
							pstmt_insertTimeDim.setInt(1, hour);
							pstmt_insertTimeDim.setInt(2, day);
							pstmt_insertTimeDim.setInt(3, week);
							pstmt_insertTimeDim.setInt(4, month);
							pstmt_insertTimeDim.setInt(5, year);				
							
							pstmt_insertTimeDim.executeUpdate();
							//System.out.println(pstmt_insertTimeDim.executeBatch());
							conn_dwhouse.commit();							
							rs_getKeyTimeDim = stmt_dwhouse.executeQuery(dbquery_getKeyTimeDim);
							rs_getKeyTimeDim.next();
							
						}
						
						key_time_dim = rs_getKeyTimeDim.getInt("key_dim");						
						
						/*Now we have everything to fill pwrconsumption_fact table*/
						String insertFactUsage = "INSERT INTO `" + "usage_fact"
								+ "` (`key_time`, `key_component`, `key_machinelocation`,`usageperhour`) values(?,?,?,?)"  ;
						
						java.sql.PreparedStatement pstmt_insertFactUsage = conn_dwhouse.prepareStatement(insertFactUsage);
						pstmt_insertFactUsage.setInt(1, key_time_dim);
						pstmt_insertFactUsage.setInt(2, key_comp_dim);
						pstmt_insertFactUsage.setInt(3, key_machinelocation);
						pstmt_insertFactUsage.setInt(4, actionsNbr);
						pstmt_insertFactUsage.executeUpdate();
						conn_dwhouse.commit();										
						
						
						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					
					}
				} finally {
					if (rs_getUsagetLog != null) {
						rs_getUsagetLog.close();
					}
					if (stmt_machine2 != null) {
						stmt_machine2.close();
					}
				}

				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	private PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final routUsageLog_machine2 routUsageLog_machine2Class = new routUsageLog_machine2();

		int exitCode = routUsageLog_machine2Class.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = routUsageLog_machine2.class.getClassLoader().getResourceAsStream(
					"nfe211_1/routUsageLog_machine2_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = routUsageLog_machine2.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				// defaultProps is in order to keep the original context value
				if (context != null && context.isEmpty()) {
					defaultProps.load(inContext);
					context = new ContextProperties(defaultProps);
				}

				inContext.close();
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBConnection_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBConnection_1) {
			globalMap.put("tDBConnection_1_SUBPROCESS_STATE", -1);

			e_tDBConnection_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory)
					+ " bytes memory increase when running : routUsageLog_machine2");
		}

		int returnCode = 0;
		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {
		closeSqlDbConnections();

	}

	private void closeSqlDbConnections() {
		try {
			Object obj_conn;
			obj_conn = globalMap.remove("conn_tDBConnection_1");
			if (null != obj_conn) {
				((java.sql.Connection) obj_conn).close();
			}
			obj_conn = globalMap.remove("conn_tDBConnection_2");
			if (null != obj_conn) {
				((java.sql.Connection) obj_conn).close();
			}
			obj_conn = globalMap.remove("conn_tDBConnection_3");
			if (null != obj_conn) {
				((java.sql.Connection) obj_conn).close();
			}
			obj_conn = globalMap.remove("conn_tDBConnection_4");
			if (null != obj_conn) {
				((java.sql.Connection) obj_conn).close();
			}
			obj_conn = globalMap.remove("conn_tDBConnection_5");
			if (null != obj_conn) {
				((java.sql.Connection) obj_conn).close();
			}
			obj_conn = globalMap.remove("conn_tDBConnection_6");
			if (null != obj_conn) {
				((java.sql.Connection) obj_conn).close();
			}
		} catch (java.lang.Exception e) {
		}
	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
		connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
		connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));
		connections.put("conn_tDBConnection_3", globalMap.get("conn_tDBConnection_3"));
		connections.put("conn_tDBConnection_4", globalMap.get("conn_tDBConnection_4"));
		connections.put("conn_tDBConnection_5", globalMap.get("conn_tDBConnection_5"));
		connections.put("conn_tDBConnection_6", globalMap.get("conn_tDBConnection_6"));

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--monitoring=")) {// for trunjob call
			enableLogStash = "true".equalsIgnoreCase(arg.substring(13));
		}

		if (!enableLogStash) {
			enableLogStash = "true".equalsIgnoreCase(System.getProperty("monitoring"));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}